<?php							

	$hostname = "localhost";
	$username = "root";
	$password = "";
	$dbname = "mobile_app";
		
	$connect = mysqli_connect($hostname, $username, $password, $dbname) OR DIE ("Connection failed");
					
	$username = $_GET["username"];
	$password = $_GET["password"];

									
	$sqlcheck = "SELECT * FROM login WHERE username = '$username'";
					
	$result = mysqli_query($connect,$sqlcheck);	
					
	if ($result) {
		if (mysqli_num_rows($result) > 0) {
			echo "Username already exist. Please insert another username.";
			exit();
		}else{
							
			$sql = "INSERT INTO login (username, password) VALUES ('$username','$password')";					
			$sendsql = mysqli_query($connect,$sql);
							
			if($sendsql)
				echo "Susccessful Register";
			else
				echo "Failed to register. Please try again.";
		}
					
	}
	
				
?>
