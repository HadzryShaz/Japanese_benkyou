<?php
							
	$hostname = "localhost";
	$user = "root";
	$password = "";
	$dbname = "mobile_app";
		
	$connect = mysqli_connect($hostname, $user, $password, $dbname) OR DIE ("Connection failed");
					
	$username = $_GET["username"];
	$password = $_GET["password"];

	$sqlcheck = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
					
	$result = mysqli_query($connect,$sqlcheck);	
					
	if ($result) {
		if (mysqli_num_rows($result) > 0) {
			echo "Susccessful login";
		}else{
			echo "Username does not exist. Please register.";
		}
	}

				
?>